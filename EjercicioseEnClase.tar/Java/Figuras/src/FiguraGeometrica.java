public abstract class FiguraGeometrica {
    protected double perimetro;
    public abstract void dibujar();
    public abstract double calcularPerimetro();

}
