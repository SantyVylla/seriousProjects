public class Main {
    public static void main(String[] args) {
        PoliComedor poliComedor = new PoliComedor();

        //poliComedor.verMenu();  //Muestra el menú
        poliComedor.elegirAlmuerzo("Almuerzo Ejecutivo 2"); //Cobra el valor del almuerzo elegido

    }
}
