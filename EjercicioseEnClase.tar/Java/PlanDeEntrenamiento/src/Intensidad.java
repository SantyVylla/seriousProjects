public enum Intensidad {
    ALTA, MEDIA, BAJA
}
