public class Dieta {
    private String descripcion;

    public Dieta(String descripcion) {
        this.descripcion = descripcion;
    }

    // Getters y setters
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
